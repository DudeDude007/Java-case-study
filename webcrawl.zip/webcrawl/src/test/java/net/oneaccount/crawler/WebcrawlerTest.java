package net.oneaccount.crawler;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class WebcrawlerTest {
	
	private Webcrawler crawler;

	@Before
	public void setUp() throws Exception {
		crawler  = new Webcrawler();
	}

	@After
	public void tearDown() throws Exception {
		crawler = null;
	}
	
    private String loadTestFile(String filename) throws Exception {
    	if (filename == null || filename.trim().isEmpty()) {
    		throw new Exception("no filename provided");
    	}
    	
    	URL url = ClassLoader.getSystemResource(filename);
    	
    	if (url == null) {
    		throw new Exception(String.format("Unable t find file: %s", filename));
    	}
        try {
            return Arrays.toString(Files.lines(Paths.get(url.toURI())).toArray());
        } catch (IOException | URISyntaxException e) {
            throw new Exception(e);
        }
    }

	@Test(expected = IllegalArgumentException.class)
	public void testGetTheNumberOfHrefUrlsNullPageData() throws Exception {
		PageData htmlPageData = new PageData(null);
		crawler.getHtmlLinkFromPage(htmlPageData);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testGetTheNumberOfHrefUrlsWithEmptyPageData() throws Exception {
		PageData htmlPageData = new PageData(new StringBuilder());
		crawler.getHtmlLinkFromPage(htmlPageData);
	}
	
	@Test
	public void testGetTheNumberOfHrefUrl() throws Exception {
		final String html=loadTestFile("elasticquery.txt");
		PageData htmlPageData = new PageData(new StringBuilder(html));
		assertEquals("Number of href links",7, crawler.getHtmlLinkFromPage(htmlPageData).size());
	}
	
	@Test
	public void testdownLoadLinkGetJSnames() throws Exception {
		List <String> list = new ArrayList<String>();
		list.add("https://www.elastic.co/");
		assertEquals("Number of js names",40,crawler.downLoadLinkGetJSnames(list).size());
	}
	

}
