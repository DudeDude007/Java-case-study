package net.oneaccount.crawler;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * This class is responsible for dealing with query or loading a page 
 * @author Rashpal Bhamra
 *
 */
public abstract class Search {

	/**
	 * Perform a search query against a search engine
	 * 
	 * @param searchQuery the search string
	 * @return {@link PageData}
	 * @throws Exception
	 */
	public abstract PageData getSearchResult(final String searchQuery) throws Exception;

	/**
	 * 
	 * This method returns the page data of the uri request
	 * @param uri the url to be requested
	 * @return html page data in {@link StringBuilder}
	 * @throws Exception if a page data can not be obtained
	 */
	public StringBuilder readPage(String uri) throws Exception {
		URL url;
		InputStream ins = null;
		BufferedReader reader;
		String line;
		StringBuilder sb = new StringBuilder();

		url = new URL(uri);
		ins = url.openStream();
		reader = new BufferedReader(new InputStreamReader(ins));

		while ((line = reader.readLine()) != null) {
			sb.append(line + "\n");
		}

		if (ins != null) {
			ins.close();
		}

		return sb;
	}
	
	/**
	 * This method retrieves html page data from the requested url
	 * @param url url link
	 * @return 
	 */
	public PageData downloadPage(final String url) throws Exception {
		return new PageData(readPage(url));
	}
	

}
