package net.oneaccount.crawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

/**
 * Main Web Crawler class
 * @author Rashpal Bhamra
 *
 */
public class Webcrawler {
    
	/**
	 * Read from standard input
	 * @return
	 * @throws IOException
	 */
    public String readInputFromStdin() throws IOException {
    	BufferedReader reader =  
                new BufferedReader(new InputStreamReader(System.in));
    	final String readLine = reader.readLine();
    	
    	if (StringUtils.isEmpty(readLine)) {
    		throw new IllegalArgumentException("Search paramater can not be empty.  Please enter a value to search");
    	}
    	return readLine;
    }
    
    /**
     * Gets a list of 'href' urls
     * @param htmlPageData html page data
     * @return
     */
    public List<String> getHtmlLinkFromPage(final PageData htmlPageData) {
    	return htmlPageData.getHtmlLinksPages();
    }
    

    /**
     * Gets a list javascript names from the list of urls, html pages
     * @param urlToDownload list or urls
     * @param search search engine, like bing or yahoo
     * @return
     * @throws Exception
     */
    public List<String> downLoadLinkGetJSnames(final List<String> urlToDownload,final Search search) throws Exception {
    	List<String> result = new ArrayList<String>();
    	PageData downloadedPage = null;
    	for (String url: urlToDownload) {
    		downloadedPage = search.downloadPage(url);
    		result.addAll(downloadedPage.getJavaScriptLib());
        }
    	
    	return result;
    }
    
    /**
     * 
     * @param urlToDownload
     * @return
     * @throws Exception
     */
    public List<String> downLoadLinkGetJSnames(final List<String> urlToDownload) throws Exception {
    	return downLoadLinkGetJSnames(urlToDownload, new BingSearch());
    }

	public static void main (String[] args) {

		Webcrawler crawler = new Webcrawler();
		Search search = new BingSearch();
		
	    // Call the SearchWeb method and print the response.
	    try {
	    	System.out.println("Enter phrase to search...");
	    	String searchString = crawler.readInputFromStdin();
	    	
	        System.out.println("Searching the Web for: " + searchString);
	        
	        // perform a search
	        PageData result = search.getSearchResult(searchString);
	        List<String> urls = crawler.getHtmlLinkFromPage(result);
	        List<String> jsNames = crawler.downLoadLinkGetJSnames(urls, search);
	        
	        System.out.println("\nSorted list :\n");
	        
	        Map<String, Integer> topJS = crawler.calculateMostUsedJS(jsNames);
	            
	        System.out.println("\nTop 5 used Javascripts: \n" + topJS.entrySet().stream()
	                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
	                .limit(10)
	                .collect(Collectors.toList()));

	    }
	    catch (Exception e) {
	        e.printStackTrace(System.out);
	        System.exit(1);
	    }
	}

	/**
	 * Return a map of <key> javascript name to <value> he number of occurrences
	 * @param jsNames
	 * @return
	 */
	private  Map<String, Integer> calculateMostUsedJS(List<String> jsNames) {
		HashSet<String> setString = new HashSet<>();

		for (int j = 0; j < jsNames.size(); j++) {
		    setString.add(jsNames.get(j));
		}

		Map<String, Integer> usedJS = new TreeMap<String, Integer>();
		
		Iterator<String> itrString =  setString.iterator();
		while(itrString.hasNext()){
		    String javaScriptName = itrString.next();
		    usedJS.put(javaScriptName,Collections.frequency(jsNames, javaScriptName));
		}
		return usedJS;
	}
}
