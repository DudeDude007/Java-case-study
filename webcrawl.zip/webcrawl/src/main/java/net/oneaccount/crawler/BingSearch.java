package net.oneaccount.crawler;

import java.net.URLEncoder;
/**
 * This class represents implementation for performing a  search query using bing search engine
 * @author Rashpal Bhamra
 *
 */
public class BingSearch extends Search {

	private static final String UTF_8 = "UTF-8";
	private static final String QUERY = "?q=";
	static String host = "https://www.bing.com";
	static String path = "/search";
	
	@Override
	public PageData getSearchResult(String searchQuery) throws Exception {
		
		// Construct the URL.
		String pageUrl = host + path + QUERY +  URLEncoder.encode(searchQuery, UTF_8);
		return new PageData(readPage(pageUrl));
	}

}
