package net.oneaccount.crawler;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

/**
 * This class represent the html page data 
 * @author Rashpal Bhamra
 *
 */
public class PageData {
	
	private static final String NO_HTML_PAGE_DATA_AVAILABLE = "No Html page data available";

	private static final String JAVA_SCRIPT_PATTERN = ".*.js[\"|'].*";

	private static final String QUOTE_ESCAPED_TAG = "\"";

	private static final String JAVA_SCRIPT_FILE_EXPRESSION = "[a-zA-Z\\.0-9]+\\.js";

	private static final String OPEN_SCRIPT_TAG = "<script";

	private static final String DOCTYPE_TAG = "<!DOCTYPE";

	private final String HREF_REG = "class=\"b_algo\"><h2><a href=\"(.*?)";
	
	// storage of html page data
	private StringBuilder htmlPage;
	
	public PageData(StringBuilder htmlResponsePage) {
		this.htmlPage = htmlResponsePage;
	}
	
	/**
	 * Get a list of urls, href from the html page
	 * @return
	 */
	public List<String> getHtmlLinksPages() {
		if (StringUtils.isEmpty(htmlPage)){
			throw new IllegalArgumentException(NO_HTML_PAGE_DATA_AVAILABLE);
		}
			
		List<String> urls = new ArrayList<String>();
		
		for (String element : htmlPage.toString().split(HREF_REG)) { // split the string on this tag
			
			if (!element.startsWith(DOCTYPE_TAG)) { // filter out DOCTYPE
				if (element.split(QUOTE_ESCAPED_TAG).length >= 1) { // split the string on tag '\'
					urls.add(element.split(QUOTE_ESCAPED_TAG)[0]);
				}
			}
		}
		
		return urls;
	}

	/**
	 * Gets a list of java script names in the html page
	 * @return
	 */
	public List<String> getJavaScriptLib()   {
		if (StringUtils.isEmpty(htmlPage)){
			throw new IllegalArgumentException(NO_HTML_PAGE_DATA_AVAILABLE);
		}
		
		List<String> jsNames = new ArrayList<String>();
		for (String element : htmlPage.toString().split(OPEN_SCRIPT_TAG)) {
			// check is .js file is present in string element
			if (element.matches(JAVA_SCRIPT_PATTERN)) {                    
				Pattern p = Pattern.compile(JAVA_SCRIPT_FILE_EXPRESSION); // compile RE for a js file name
				Matcher m = p.matcher(element);
				while (m.find()) {  // if there is a match add java script name to list
					jsNames.add(m.group(0)); 
				}
			}
			
		}
		return jsNames;
	}
	
	
}
